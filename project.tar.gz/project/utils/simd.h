
#pragma once
#include <immintrin.h>
void* multiply_matrix_simd_thread(void *arg);
void* multiply_matrix_simd_thread2(void *arg);